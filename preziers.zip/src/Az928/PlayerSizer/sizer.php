<?php

namespace Az928\PlayerSizer;

use pocketmine\plugin\PluginBase as core;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\Server;
use pocketmine\Player;

class sizer extends Command{
    
    private $p;
    public function __construct($plugin){
        $this->p = $plugin;
        parent::__construct("size", "PlayerSizer plugin!");
    }
    
    public function execute(CommandSender $sender, $label, array $args){
        if($sender->hasPermission("sizer.".$args[0])){
            if(isset($args[0])){
                if(is_numeric($args[0]) && $args[0] <= 3){
                    $this->p->a[$sender->getName()] = $args[0];
                    $sender->setDataProperty(Entity::DATA_SCALE, Entity::DATA_TYPE_FLOAT, $args[0]);
                    $sender->sendMessage("§c# §aYour size changed to §e".$args[0]);
                }elseif($args[0] == "reset"){
                    if(!empty($this->p->a[$sender->getName()])){
                        unset($this->p->a[$sender->getName()]);
                        $sender->setDataProperty(Entity::DATA_SCALE, Entity::DATA_TYPE_FLOAT, 1);
                        $sender->sendMessage("§c# §aYour size has been set to §enormal");
                    }else{
                        $sender->sendMessage("§c# §aYour size has been resetted!!");
                    }
                }else{
                    $sender->sendMessage("[<-*->]§eCommands for §bPlayerSizer: \n§6/size help §7- shows all the commands!\n§6/size reset §7- Resets the size!\n§6/size §3(0.2-3) §7- Manage your size!\n§3«---------------------------------»");
                }
            }else{
               $sender->sendMessage("§7>§c Size over 3 or 0 isn't appreciated!");
          }
	  }else{
		 $sender->sendMessage("§cYou don't have permission for that size!");
	}
  }
}