<?php

namespace Az928\PlayerSizer;

use pocketmine\plugin\PluginBase as core;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\Server;
use pocketmine\Player;

class other extends Command{
    
    private $p;
    public function __construct($plugin){
        $this->p = $plugin;
        parent::__construct("sizeother", "PlayerSizer plugin!");
    }
    
    public function execute(CommandSender $sender, $label, array $args){
        if($sender->hasPermission("sizer.other")){
            if(isset($args[0]) && isset($args[1])){
	            if(is_numeric($args[0])){
		           $other = $this->p->getServer()->getPlayer($args[1]);
		           $size = $args[0];
		           if($other !== null){
			           $this->p->a[$other->getName()] = $args[0];
			           $other->setDataProperty(Entity::DATA_SCALE, Entity::DATA_TYPE_FLOAT, $args[0]);
			           $other->sendMessage("§c#§a Your size was changed to §e".$args[0]);
			           $sender->sendMessage("§c# §aSize of §e".$other->getName()."§a has been changed to §e".$args[0]);
			 }else{
			   $sender->sendMessage("§cPlayer not online!");
			}
		   }else{
		      $sender->sendMessage("§cUsage:§7 /sizeother {size} <PlayerNam>");
			}
	    }else{
		  $sender->sendMessage("§cUsage:§7 /sizeother {size} <PlayerNam>");
	    }
	  }else{
		$sender->sendMessage("§cYou don't have permission to change others size!");
	  }
	}
}